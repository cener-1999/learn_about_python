# pyqt5-QQ
利用python PyQt5图形库开发的一个基于tcp协议仿QQ聊天pc软件工具<br>
----
*软件介绍：<br>
---
>>运行启动<br>
>>功能展示<br>
>>源码详解介绍<br>

*运行启动<br>
---
>>由于本软件基于tcp协议开发，首先要运行服务端Tcp_server.py,再运行login.py文件即可看到软件界面（开发工具pycharm）<br>

*功能展示<br>
----
>>Tcp_server.py服务端控制台打印信息<br>
![image](https://github.com/WEIYANLIN1996/pyqt5-QQ/blob/master/introduction-img/图片8.png)
>>登录界面<br>
![image](https://github.com/WEIYANLIN1996/pyqt5-QQ/blob/master/introduction-img/图片18.jpg)
>>主界面<br>
![image](https://github.com/WEIYANLIN1996/pyqt5-QQ/blob/master/introduction-img/图片30.jpg)
>>聊天界面(可个人聊天、群聊)<br>
![image](https://github.com/WEIYANLIN1996/pyqt5-QQ/blob/master/introduction-img/图片22.jpg)
*源码详解介绍<br>
>>最近没什么时间，有空更新，不懂可加qq：2097557613
